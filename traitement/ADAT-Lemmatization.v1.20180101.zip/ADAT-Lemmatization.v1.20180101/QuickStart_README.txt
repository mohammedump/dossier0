                ADAT: AlKhalil for Disambiguation of Arabic Text Version 1.0
               ==================================

This file provides quick start up instructions for ADAT-Analyzer-1.0 
-------------------------
1. Requirements:
-------
	1.1. 2GB of RAM memory.
	1.2. Java version 1.7.* or more recent.
-------------------------
2. Running ADAT:
-------
	2.1. Lemmatization (lemma):
		Use the following command to process an raw file.
		% java -jar ADAT-Analyzer-20180101-1.0.jar
			--rawinput="file.txt" --rawoutput="file-Lemma.txt" --choice="lemma"
	-------		
	2.2. Light Stemmer (stem):
		Use the following command to process an raw file.
		% java -jar ADAT-Analyzer-20180101-1.0.jar
			-i="file.txt"
			-o="file-Stem.txt" -oe="cp1256"
			-c="stem"
	-------
	2.2. Heavy Stemmer (root):		
		Use the following command to process an raw file.
		% java -jar ADAT-Analyzer-20180101-1.0.jar
			--rawinput="file.txt" --rawinputencoding="utf-8" 
			--rawoutput="file-Root.txt" --rawoutputencoding="utf-8"
			--choice="root"
			

