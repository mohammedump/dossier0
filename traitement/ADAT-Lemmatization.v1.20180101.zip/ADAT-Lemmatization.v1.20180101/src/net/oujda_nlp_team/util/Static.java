package net.oujda_nlp_team.util;
/*============================================================================*/
/**
 * 
 * ADAT : AlKhalil for Disambiguation of Arabic Texts
 * © 2018
 * @author Mohamed BOUDCHICHE
 * @email moha.boudchiche@gmail.com
 * 
 */
/*============================================================================*/
public class Static {
/*============================================================================*/
    public static boolean StaticUnvoweled = false;
    public static boolean isArabicLangue = true;
/*============================================================================*/
}
