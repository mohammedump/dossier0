import requests

#for the JSON output
#url = 'http://localhost:8080/api/alkhalilJson'

#For the XML output
url = 'http://localhost:8080/api/alkhalil'

textinput = 'المنظمة العربية للتربية والثقافة والعلوم' 


payload = {'textinput': textinput}

response = requests.post(url, data=payload)

if response.status_code == 200:
    result = response.text
    print(f"Result in XML format: \n{result}")
else:
    print("Error during API request.")
