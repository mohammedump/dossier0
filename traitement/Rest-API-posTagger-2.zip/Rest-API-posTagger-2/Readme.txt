The Rest API can be used from several languages such as Java and Python. 
To run the Rest API on your local machine:  
  1) You need java version 17 or higher 
  2) Run: 
        java -jar Rest-API-posTagger-2.jar

This will start a local server running on port 8080 on your machine. 

"test_pos.py" is an example of Python code calling the Rest API from your local machine.



You can use Docker to run the Rest API from any unused port of your machine. A Docker file is provided. 

    1) Install Docker if not already installed (https://docs.docker.com/engine/install)
    2) Build the pos image:
        docker build -t pos .
    3) Run Docker on any port, for example 8082:
        docker run -p 8082:8080 pos
    3) Change the URL in "test_alkhalil.py" as follows:
        url = 'http://localhost:8082/api/pos'

Enjoy!
