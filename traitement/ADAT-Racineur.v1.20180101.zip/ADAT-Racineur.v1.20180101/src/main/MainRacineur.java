package main;
/*============================================================================*/
/**
 * 
 * ADAT : AlKhalil for Disambiguation of Arabic Texts
 * © 2018
 * @author Mohamed BOUDCHICHE
 * @email moha.boudchiche@gmail.com
 * 
 */
/*============================================================================*/
public class MainRacineur {
    public static void main(String[] args) {        
        
        //HMM
        net.oujda_nlp_team.ADATAnalyzer.getInstance().processHeavyStemmer("File-IN.txt", "utf-8", "File-OUT-Root1.txt", "utf-8");
        //Spline
        net.oujda_nlp_team.ADATAnalyzer1.getInstance().processHeavyStemmer("File-IN.txt", "utf-8", "File-OUT-Root2.txt", "utf-8");        
        
    }
}
