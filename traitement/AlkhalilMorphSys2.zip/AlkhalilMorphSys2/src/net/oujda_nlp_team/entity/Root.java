   package net.oujda_nlp_team.entity;
   
   import java.io.Serializable;
   
   public class Root implements Serializable {
     private static final long serialVersionUID = 1234L;
     
     private String val;
     
     private String len1;
     
     private String len2;
     
     private String len3;
     
     private String len4;
     
     private String len5;
     
     private String len6;
     
     private String len7;
     
     private String len8;
     
     private String len9;
     
     private String len10;
     
     private String len11;
     
     private String len12;
     
     private String freq;
     
     public void setVal(String _val) {
       this.val = _val;
     }
     
     public void setLen1(String _len1) {
       this.len1 = _len1;
     }
     
     public void setLen2(String _len2) {
       this.len2 = _len2;
     }
     
     public void setLen3(String _len3) {
       this.len3 = _len3;
     }
     
     public void setLen4(String _len4) {
       this.len4 = _len4;
     }
     
     public void setLen5(String _len5) {
       this.len5 = _len5;
     }
     
     public void setLen6(String _len6) {
       this.len6 = _len6;
     }
     
     public void setLen7(String _len7) {
       this.len7 = _len7;
     }
     
     public void setLen8(String _len8) {
       this.len8 = _len8;
     }
     
     public void setLen9(String _len9) {
       this.len9 = _len9;
     }
     
     public void setLen10(String _len10) {
       this.len10 = _len10;
     }
     
     public void setLen11(String _len11) {
       this.len11 = _len11;
     }
     
     public void setLen12(String _len12) {
       this.len12 = _len12;
     }
     
     public void setFreq(String _freq) {
       this.freq = _freq;
     }
     
     public String getVal() {
       return this.val;
     }
     
     public String getLen1() {
       return this.len1;
     }
     
     public String getLen2() {
       return this.len2;
     }
     
     public String getLen3() {
       return this.len3;
     }
     
     public String getLen4() {
       return this.len4;
     }
     
     public String getLen5() {
       return this.len5;
     }
     
     public String getLen6() {
       return this.len6;
     }
     
     public String getLen7() {
       return this.len7;
     }
     
     public String getLen8() {
       return this.len8;
     }
     
     public String getLen9() {
       return this.len9;
     }
     
     public String getLen10() {
       return this.len10;
     }
     
     public String getLen11() {
       return this.len11;
     }
     
     public String getLen12() {
       return this.len12;
     }
     
     public String getFreq() {
       return this.freq;
     }
     
     public String toString() {
       return this.val + ";" + this.len1 + ";" + this.len2 + ";" + this.len3 + ";" + this.len4 + ";" + this.len5 + ";" + this.len6 + ";" + this.len7 + ";" + this.len8 + ";" + this.len9 + ";" + this.len10 + ";" + this.len11 + ";" + this.len12 + ";" + this.freq;
     }
   }


