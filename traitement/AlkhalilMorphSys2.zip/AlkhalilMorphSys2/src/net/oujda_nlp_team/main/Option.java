   package net.oujda_nlp_team.main;
   
   class Option {
     String flag;
     
     String opt;
     
     public Option(String flag, String opt) {
       this.flag = flag;
       this.opt = opt;
     }
   }
