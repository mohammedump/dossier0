   package net.oujda_nlp_team.main;
   
   class Option1 {
     String flag;
     
     String opt;
     
     public Option1(String flag, String opt) {
       this.flag = flag;
       this.opt = opt;
     }
   }
