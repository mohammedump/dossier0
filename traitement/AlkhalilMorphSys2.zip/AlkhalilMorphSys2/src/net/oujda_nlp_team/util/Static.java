   package net.oujda_nlp_team.util;
   
   public class Static {
     public static boolean StaticUnvoweled = false;
     
     public static boolean isArabicLangue = true;
   }
