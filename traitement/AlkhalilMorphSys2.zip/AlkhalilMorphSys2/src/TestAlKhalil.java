
public class TestAlKhalil {

	public static void main(String[] args) {
		
		
		net.oujda_nlp_team.entity.ResultList rsl = net.oujda_nlp_team.AlKhalil2Analyzer.getInstance().processToken("لأنهم");
		
		for(net.oujda_nlp_team.entity.Result rs : rsl.getAllResults()) {
			System.out.println(rs.getLemma());
		}

	}

}
