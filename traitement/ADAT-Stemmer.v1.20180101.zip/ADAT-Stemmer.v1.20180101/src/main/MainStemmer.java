package main;
/*============================================================================*/
/**
 * 
 * ADAT : AlKhalil for Disambiguation of Arabic Texts
 * © 2018
 * @author Mohamed BOUDCHICHE
 * @email moha.boudchiche@gmail.com
 * 
 */
/*============================================================================*/
public class MainStemmer {
    public static void main(String[] args) {
        
        //HMM
        net.oujda_nlp_team.ADATAnalyzer.getInstance().processLightStemmer("File-IN.txt", "utf-8", "File-OUT-Stem1.xml", "utf-8");
        //Spline
        //net.oujda_nlp_team.ADATAnalyzer1.getInstance().processLightStemmer("File-IN.txt", "utf-8", "File-OUT-Stem2.txt", "utf-8"); 
//        
    }
}
